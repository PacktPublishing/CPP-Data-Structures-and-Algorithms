// Project: Singly_Linked_List.cbp
// File   : main.cpp
#include <iostream>
#include "Node.h"
#include "LinkedList.h"

using namespace std;

int main()
{
    LinkedList<int> ll = LinkedList<int>();
    ll.InsertHead(50);
    ll.InsertHead(21);
    ll.InsertHead(89);
    ll.InsertHead(43);
    ll.InsertHead(76);
    ll.InsertTail(90);
    ll.InsertTail(15);
    ll.InsertTail(44);
    ll.Insert(1, 48);
    ll.Insert(5, 22);
    ll.Insert(0, 100);
    ll.Insert(1, 15);


    ll.PrintList();

    Node<int> * nn = ll.Get(2);

    if(nn != NULL)
        cout << nn->Value << endl;
    else
        cout << "null" << endl;

    int ii = ll.Search(15);
    cout << ii << endl;
    ii = ll.Search(50);
    cout << ii << endl;

    cout << "remove 1" << endl;
    ll.Remove(1);
    ll.PrintList();

    cout << "remove 2" << endl;
    ll.Remove(2);
    ll.PrintList();

    cout << "remove 9" << endl;
    ll.Remove(9);
    ll.PrintList();

    cout << "remove 0" << endl;
    ll.Remove(0);
    ll.PrintList();

    cout << "remove 10" << endl;
    ll.Remove(10);
    ll.PrintList();

    cout << "remove 50" << endl;
    ll.Remove(50);
    ll.PrintList();

    cout << "remove 4" << endl;
    ll.Remove(4);
    ll.PrintList();

    cout << "remove 7" << endl;
    ll.Remove(7);
    ll.PrintList();


    return 0;
}
