// Project: Singly_Linked_List.cbp
// File   : Node.cpp
