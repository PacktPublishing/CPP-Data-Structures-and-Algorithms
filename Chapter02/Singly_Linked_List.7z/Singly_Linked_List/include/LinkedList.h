// Project: Singly_Linked_List.cbp
// File   : LinkedList.h
#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>
#include "Node.h"

template <typename T>
class LinkedList
{
private:
    int m_count;

public:
    // The first node in the list
    // or null if empty
    Node<T> * Head;

    // The last node in the list
    // or null if empty
    Node<T> * Tail;

    // Constructor
    LinkedList();

    // Get() operation
    Node<T> * Get(int index);

    // Insert() operation
    void InsertHead(T val);
    void InsertTail(T val);
    int Insert(int index, T val);

    // Search() operation
    int Search(T val);

    // Remove() operation
    void RemoveHead();
    void RemoveTail();
    void Remove(int index);

    // Additional operation
    int Count();
    void PrintList();
};

template <typename T>
LinkedList<T>::LinkedList() : m_count(0), Head(NULL), Tail(NULL) {}

template <typename T>
Node<T> * LinkedList<T>::Get(int index)
{
    // Check if the index is out of bound
    if(index < 0 || index > m_count)
        return NULL;

    Node<T> * node = Head;

    for(int i = 0; i < index; ++i)
    {
        node = node->Next;
    }

    return node;
}

template <typename T>
void LinkedList<T>::InsertHead(T val)
{
    Node<T> * node = new Node<T>(val);
    node->Next = Head;
    Head = node;

    if(m_count == 0)
        Tail = Head;

    m_count++;
}

template <typename T>
void LinkedList<T>::InsertTail(T val)
{
    // If the linked list is empty,
    // just simply invoke InsertHead()
    if(m_count == 0)
    {
        InsertHead(val);
        return;
    }

    Node<T> * node = new Node<T>(val);
    Tail->Next = node;
    Tail = node;

    m_count++;
}

template <typename T>
int LinkedList<T>::Insert(int index, T val)
{
    // Check if the index is out of bound
    if(index < 0 || index > m_count)
        return -1;

    if(index == 0)
    {
        InsertHead(val);
        return 0;
    }
    else if(index == m_count)
    {
        InsertTail(val);
        return 0;
    }

    Node<T> * preNode = Head;

    for(int i = 0; i < index - 1; ++i)
    {
        preNode = preNode->Next;
    }

    Node<T> * aftNode = preNode->Next;

    Node<T> * node = new Node<T>(val);
    node->Next = aftNode;
    preNode->Next = node;

    m_count++;

    return 0;
}

template <typename T>
int LinkedList<T>::Search(T val)
{
    // If LinkedList is empty,
    // just return NOT_FOUND
    if(m_count == 0)
        return -1;

    int index = 0;
    Node<T> * node = Head;

    while(node->Value != val)
    {
        index++;
        node = node->Next;
        if(node == NULL)
        {
            return -1;
        }
    }

    return index;
}

template <typename T>
void LinkedList<T>::RemoveHead()
{
    // Do nothing if list is empty
    if(m_count == 0)
        return;

    Node<T> * node = Head;
    Head = Head->Next;
    delete node;

    m_count--;
}

template <typename T>
void LinkedList<T>::RemoveTail()
{
    // Do nothing if list is empty
    if(m_count == 0)
        return;

    // If List element is only one
    // just simply call RemoveHead()
    if(m_count == 1)
    {
        RemoveHead();
        return;
    }

    //Node<T> * preNode = Get(m_count - 2);
    //preNode->Next = NULL;
    ////delete Tail;
    //Tail = preNode;

    Node<T> * preNode = Head;
    Node<T> * node = Head->Next;

    while(node->Next != NULL)
    {
        preNode = preNode->Next;
        node = node->Next;
    }

    preNode->Next = NULL;
    Tail = preNode;
    delete node;

    m_count--;
}

template <typename T>
void LinkedList<T>::Remove(int index)
{
    // Do nothing if list is empty
    if(m_count == 0)
        return;

    // Do nothing if index is out of bound
    if(index < 0 || index >= m_count)
        return;

    if(index == 0)
    {
        RemoveHead();
        return;
    }

    Node<T> * preNode = Head;

    for(int i = 0; i < index - 1; ++i)
    {
        preNode = preNode->Next;
    }

    Node<T> * node = preNode->Next;
    Node<T> * aftNode = node->Next;

    preNode->Next = aftNode;

    delete node;

    m_count--;

}

template <typename T>
int LinkedList<T>::Count()
{
    return m_count;
}

template <typename T>
void LinkedList<T>::PrintList()
{
    Node<T> * node = Head;

    while(node != NULL)
    {
        std::cout << node->Value << " -> ";
        node = node->Next;
    }

    std::cout << "NULL" << std::endl;
}


#endif // LINKEDLIST_H
